const { google } = require('googleapis');
const mysql = require('mysql2/promise');
const express = require('express');
const cors = require('cors');
const app = express();
const path = require('path');

app.use(express.json());
app.use(cors());

// Google Sheets configuration
const auth = new google.auth.GoogleAuth({
  keyFile: path.join(__dirname, 'credentials.json'),
  scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly'],
});


async function startServer() {
  const client = await auth.getClient();
  const sheets = google.sheets({ version: 'v4', auth: client });

  // MySQL connection 
  const pool = mysql.createPool({
    host: 'localhost',
    user: '5goal',
    password: 'Loma@123!',
    database: '5goal_wordpress',
    connectionLimit: 10,
  });

  // Sync Endpoint: Fetch and Update Map Data from Sheet
  app.post('/maps/sync', async (req, res) => {
    let connection;
    try {
      connection = await pool.getConnection();
      const spreadsheetId = '1Ua0GVJsemKFQh5MjpH7LHvB4tFplA-9OV9Hu0Yed6oI'; 
      const range = 'Sheet1!A2:H'; 
      const response = await sheets.spreadsheets.values.get({ spreadsheetId, range });
      const rows = response.data.values;

      if (!rows || rows.length === 0) {
        return res.status(404).send('No data found');
      }

      for (const row of rows) {
        const [id, raceTrackID, name_vi, name_en, turns, quant, laps, length] = [
          row[0] || null, // ID (ignored unless needed)
          row[1] || null, // Track Code as raceTrackID
          row[2] || null, // name_vi
          row[3] || null, // name_en
          row[4] !== undefined ? parseInt(row[4]) : null, // turns (NULL if undefined)
          row[5] || null, // quant
          row[6] !== undefined ? parseInt(row[6]) : null, // laps (NULL if undefined)
          row[7] !== undefined ? parseFloat(row[7]) : null, // length (NULL if undefined)
        ];
        if (raceTrackID) {
          await connection.execute(
            `INSERT INTO map (raceTrackID, name_vi, name_en, turns, quant, laps, length)
             VALUES (?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
             name_vi = VALUES(name_vi),
             name_en = VALUES(name_en),
             turns = VALUES(turns),
             quant = VALUES(quant),
             laps = VALUES(laps),
             length = VALUES(length)`,
            [raceTrackID, name_vi, name_en, turns, quant, laps, length]
          );
        }
      }

      res.status(200).send('Data synced successfully');
    } catch (error) {
      console.error('Sync error:', error.message, error.stack);
      res.status(500).send('Error syncing data');
    } finally {
      if (connection) connection.release();
    }
  });

  // Fetch Endpoint: Get All Data from Database
  app.get('/maps/all', async (req, res) => {
    let connection;
    try {
      connection = await pool.getConnection();
      console.log('Fetching data from database...');
      const [rows] = await connection.execute('SELECT * FROM map');
      console.log('Fetched rows:', rows);
      res.status(200).json(rows);
    } catch (error) {
      console.error('Fetch error:', error.message, error.stack);
      res.status(500).send('Error fetching data');
    } finally {
      if (connection) connection.release();
    }
  });

  // Start Server
  const PORT = 3000;
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer().catch(console.error);

// Graceful shutdown
process.on('SIGTERM', async () => {
  await pool.end();
  process.exit(0);
});

process.on('SIGINT', async () => {
  await pool.end();
  process.exit(0);
});